#ifndef UTILITY_H
#define UTILITY_H

#include <stdio.h>

char *getLine(char *, int, FILE *);
void printBytes(char *, int);

#endif /* UTILITY_H */
