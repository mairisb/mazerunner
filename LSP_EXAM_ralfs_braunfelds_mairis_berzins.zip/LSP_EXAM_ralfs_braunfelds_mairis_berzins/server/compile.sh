gcc -o server main.c libs/servercfg.c libs/utility.c libs/move_queue.c -lpthread -Wall -std=c90 -g
