#ifndef UTILITY_H
#define UTILITY_H

#include <stdio.h>

char *getLine(char *, int, FILE *);
int strToInt(char *, int);

#endif /* UTILITY_H */
